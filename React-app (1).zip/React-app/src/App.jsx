import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header2 from './Components/Header2';
import MainContent from './Components/MainContent';
import Footer from './Components/Footer';
import Services from './Components/Services';
 import About2 from './Components/About2';





// CV
// import Profile from './Components/Profile';
// import Experience from './Components/Experience';
// import Skills from './Components/Skills';
// import Contact2 from './Components/Contact2';
// Portfolio
//  import About from './Components/About';
//  import Projects from './Components/Project';
//  import Contact from './Components/Contact';
//  import Header from './Components/Header';

function App() {
  return (
    <>
    {/* CV */}
      {/* <div className="container mx-auto p-4"> */}
        {/* <Profile /> */}
        {/* <Experience /> */}
        {/* <Skills /> */}
        {/* <Contact2 /> */}
      {/* </div> This div was not closed properly */}
      {/* portfolio */}

      {/* <div> */}
      {/* <Header /> */}
      {/* <main> */}
        {/* <About /> */}
        {/* <Projects /> */}
        {/* <Contact /> */}
      {/* </main> */}
      {/* </div> */}
      <div className="App">
        <Header2/>
        <Routes>
        <Route path="/" element={<MainContent />} />
        <Route path="/About2" element={<About2 />} />
        <Route path="/Services" element={<Services />} />
      </Routes>
        

        <Footer/>

      </div>
      
      
      
      
      
      
      
    
    
      
    
      
      
    

      
    
     
    </>
  );
}

export default App;  // This is correct and should be done only once in a file
