// src/components/About.js
import React from 'react';

const About2 = () => {
  return (
    <section className="bg-gray-100 text-red-600 py-20">
      <div className="container mx-auto text-center">
        <h2 className="text-4xl font-bold mb-4">About Us</h2>
        <p className="text-lg">Learn more about our mission and values.</p>
      </div>
    </section>
  );
}

export default About2;
