// src/components/Services.js
import React from 'react';

const Services = () => {
  return (
    <section className="bg-gray-100 text-red-600 py-20">
      <div className="container mx-auto text-center">
        <h2 className="text-4xl font-bold mb-4">Our Services</h2>
        <p className="text-lg">Discover the services we offer to help you succeed.</p>
      </div>
    </section>
  );
}

export default Services;
