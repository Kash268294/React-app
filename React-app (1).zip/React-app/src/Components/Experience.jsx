import React from 'react';

const Experience = () => {
  return (
    <div className="bg-gradient-to-r from-red-400 via-purple-500 to-pink-500 p-8 rounded-lg shadow-lg mt-6">
      <h2 className="text-3xl font-bold text-white mb-6">Experience</h2>

      {/* Intern Experience */}
      <div className="mb-6 bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 ease-in-out">
        <h3 className="text-2xl font-bold text-purple-800">Intern at XYZ Company</h3>
        <p className="text-sm text-gray-500">Jan 2024 - Present</p>
        <p className="text-gray-700 mt-2">
          Working on frontend development using React.js and Tailwind CSS.
        </p>
      </div>

      {/* Freelance Experience */}
      <div className="mb-6 bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 ease-in-out">
        <h3 className="text-2xl font-bold text-purple-800">Freelance Developer</h3>
        <p className="text-sm text-gray-500">May 2023 - Dec 2023</p>
        <p className="text-gray-700 mt-2">
          Developed multiple responsive websites for small businesses.
        </p>
      </div>
    </div>
  );
};
