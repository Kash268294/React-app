import React from 'react';

const Skills = () => {
  return (
    <div className="bg-gradient-to-r from-red-100 to-pink-200 p-8 rounded-lg shadow-lg mt-6">
      <h2 className="text-3xl font-semibold text-gray-800 mb-4">Skills</h2>
      <ul className="list-disc list-inside text-lg text-gray-700 space-y-2">
        <li>React.js & JavaScript</li>
        <li>HTML & CSS</li>
        <li>Tailwind CSS</li>
        <li>Responsive Design</li>
        <li>APIs & Fetching Data</li>
      </ul>
    </div>
  );
};

export default Skills;
