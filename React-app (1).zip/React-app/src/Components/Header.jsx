import React from 'react';

const Header = () => (
  <header className="bg-gray-800 text-white p-4 shadow-md">
    <div className="container mx-auto flex justify-between items-center flex-wrap">
      <h1 className="text-2xl font-bold md:text-3xl">My Portfolio</h1>
      <nav>
        <ul className="flex space-x-4 mt-2 md:mt-0 flex-wrap justify-center md:justify-end">
          <li>
            <a href="#about" className="text-white hover:text-blue-300 hover:underline transition-colors duration-300">
              About
            </a>
          </li>
          <li>
            <a href="#projects" className="text-white hover:text-blue-300 hover:underline transition-colors duration-300">
              Projects
            </a>
          </li>
          <li>
            <a href="#contact" className="text-white hover:text-blue-300 hover:underline transition-colors duration-300">
              Contact
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </header>
);

export default Header;
