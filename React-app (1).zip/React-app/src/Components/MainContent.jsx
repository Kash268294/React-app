// src/components/MainContent.js
import React from 'react';
import ContactForm from './ContactForm';

const MainContent = () => {
  return (
    <section className="bg-white text-red-600 py-20">
      <div className="container mx-auto text-center">
        <h2 className="text-4xl font-bold mb-4">Welcome to Young Dev Clone</h2>
        <p className="text-lg mb-8">A platform for young developers to showcase their skills.</p>
        <a href="#get-started" className="bg-red-600 text-white px-6 py-3 rounded-full">Get Started</a>
      </div>
      <ContactForm /> {/* Add ContactForm */}
    </section>
  );
}

export default MainContent;

