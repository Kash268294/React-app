import React from 'react';

function Contact2() {
  return (
    <div className="bg-gradient-to-r from-green-400 to-blue-500 p-8 rounded-lg text-white mt-6">
      <h2 className="text-3xl font-semibold mb-4">Contact Me</h2>
      <p className="mb-4">Feel free to reach out to me via email or LinkedIn.</p>

      <button className="mt-4 bg-white text-green-500 font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105 hover:bg-green-500 hover:text-white hover:bg-green-500">
        Email Me
      </button>
    </div>
  );
}

export default Contact2;
