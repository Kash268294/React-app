import React from 'react';

const Profile = () => {
  return (
    <div className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 p-8 rounded-lg text-white">
      <h1 className="text-4xl font-bold mb-4">Yar Baroque</h1>
      <p className="text-lg">Aspiring Software Developer</p>
      <p className="text-sm mt-2">Location: Your City, Country</p>
      <p className="text-sm mt-2">Email: yar@example.com</p>
    </div>
  );
};

export default Profile;
