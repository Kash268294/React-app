import React from 'react';

const Contact = () => (
  <section id="contact" className="py-16 bg-gradient-to-r from-green-400 to-blue-500">
    <div className="container mx-auto px-4 text-center">
      <h2 className="text-3xl font-bold text-white mb-6 md:text-4xl">Contact Me</h2>
      <p className="text-base md:text-lg mb-4 text-white leading-relaxed">
        I would love to hear from you! Feel free to reach out via email or use the form below.
      </p>
      <a
        href="mailto:your.email@example.com"
        className="mt-4 inline-block bg-white text-green-500 font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105 hover:bg-green-600 hover:text-white"
      >
        Email Me
      </a>
      <div className="mt-8 max-w-md mx-auto">
        <form
          action="https://formspree.io/f/your-form-id" // Replace with your Formspree or other form handling URL
          method="POST"
          className="bg-white p-6 rounded-lg shadow-lg"
        >
          <div className="mb-4">
            <label htmlFor="name" className="block text-gray-700 font-bold mb-2">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              required
              className="w-full border border-gray-300 rounded-lg py-2 px-3 text-gray-700 focus:outline-none focus:border-green-500"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block text-gray-700 font-bold mb-2">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              required
              className="w-full border border-gray-300 rounded-lg py-2 px-3 text-gray-700 focus:outline-none focus:border-green-500"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="message" className="block text-gray-700 font-bold mb-2">Message</label>
            <textarea
              id="message"
              name="message"
              rows="4"
              required
              className="w-full border border-gray-300 rounded-lg py-2 px-3 text-gray-700 focus:outline-none focus:border-green-500"
            ></textarea>
          </div>
          <button
            type="submit"
            className="w-full bg-green-500 text-white font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105 hover:bg-green-600"
          >
            Send Message
          </button>
        </form>
      </div>
    </div>
  </section>
);

export default Contact;
